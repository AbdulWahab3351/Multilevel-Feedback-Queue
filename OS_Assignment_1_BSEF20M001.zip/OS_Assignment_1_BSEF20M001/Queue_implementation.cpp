#include "Queue.cpp"
#include"Process.h"
template class Queue<struct Process>;
