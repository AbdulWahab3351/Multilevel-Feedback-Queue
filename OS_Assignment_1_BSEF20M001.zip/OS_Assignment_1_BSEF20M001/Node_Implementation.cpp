#include"Node.cpp"
#include"Process.h"

template class Node<struct Process>;
